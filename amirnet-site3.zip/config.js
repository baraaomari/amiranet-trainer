/* مفاتيح مشروعك — لا يدخل هذا الملف المستودع. */
window.SUPABASE_CONFIG = {
  url: "https://fldilbmevccaspznbpkt.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZsZGlsYm1ldmNjYXNwem5icGt0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg2MTI1MTYsImV4cCI6MjEwNDE4ODUxNn0.Kv6gtPU3jCiky2fXkY1SJmLVkam_6xotzuBKWvUmKQQ",
  tutorFunction: "tutor"
};
